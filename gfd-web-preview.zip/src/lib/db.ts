import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

export async function getBenchmarks() {
  const data = await prisma.benchmark.findMany({ orderBy: { asOf: 'desc' } })
  return data.map(b => ({ id: b.id, commodity: b.commodity, value: Number(b.value), currency: '€' as const, asOf: b.asOf.toISOString() }))
}

export async function getTrades() {
  const data = await prisma.trade.findMany({ orderBy: { date: 'desc' }, take: 50 })
  return data.map(t => ({
    id: t.id, commodity: t.commodity, side: t.side as 'BUY' | 'SELL', qty: t.qty, price: Number(t.price), incoterm: t.incoterm, location: t.location, date: t.date.toISOString()
  }))
}