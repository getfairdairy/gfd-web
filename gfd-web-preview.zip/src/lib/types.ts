export type Benchmark = { id: string; commodity: string; value: number; currency: '€' | '$'; asOf: string }
export type Trade = {
  id: string; commodity: string; side: 'BUY' | 'SELL'; qty: number; price: number; incoterm: string; location: string; date: string
}