import { NextResponse } from 'next/server'
import { getTrades } from '@/lib/db'

export async function GET() {
  const data = await getTrades()
  return NextResponse.json({ data })
}