import { getBenchmarks } from '@/lib/db'

export default async function Dashboard() {
  const benchmarks = await getBenchmarks()
  return (
    <section className="w-full max-w-6xl mx-auto px-4 md:px-6 py-10">
      <h2 className="text-2xl font-bold mb-4">Benchmarks</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {benchmarks.map(b => (
          <div key={b.id} className="rounded-2xl border bg-white p-4">
            <div className="text-xs uppercase tracking-wider text-gray-500">{b.commodity}</div>
            <div className="text-2xl font-semibold">{b.value} {b.currency}</div>
            <div className="text-sm text-gray-500">as of {new Date(b.asOf).toLocaleDateString()}</div>
          </div>
        ))}
      </div>
    </section>
  )
}