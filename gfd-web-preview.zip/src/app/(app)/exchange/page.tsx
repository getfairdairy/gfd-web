import { getTrades } from '@/lib/db'

export default async function Exchange() {
  const trades = await getTrades()
  return (
    <section className="w-full max-w-6xl mx-auto px-4 md:px-6 py-10">
      <h2 className="text-2xl font-bold mb-4">Trade Blotter</h2>
      <div className="rounded-2xl border overflow-x-auto bg-white">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left p-3">Date</th>
              <th className="text-left p-3">Commodity</th>
              <th className="text-left p-3">Side</th>
              <th className="text-left p-3">Qty</th>
              <th className="text-left p-3">Price</th>
              <th className="text-left p-3">Incoterm</th>
              <th className="text-left p-3">Location</th>
            </tr>
          </thead>
          <tbody>
            {trades.map(t => (
              <tr key={t.id} className="border-t">
                <td className="p-3">{new Date(t.date).toLocaleDateString()}</td>
                <td className="p-3">{t.commodity}</td>
                <td className="p-3">{t.side}</td>
                <td className="p-3">{t.qty} MT</td>
                <td className="p-3">€{t.price}</td>
                <td className="p-3">{t.incoterm}</td>
                <td className="p-3">{t.location}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}