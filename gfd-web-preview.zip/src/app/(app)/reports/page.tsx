export default function Reports() {
  return (
    <section className="w-full max-w-6xl mx-auto px-4 md:px-6 py-10">
      <h2 className="text-2xl font-bold mb-2">Reports</h2>
      <p className="text-gray-600">Hook this to your WordPress feed next. For now, static placeholder.</p>
      <ul className="mt-4 list-disc pl-6">
        <li>Weekly Market Pulse — Cream tight, whey softer</li>
        <li>3–6 month outlook — Sideways baseline, upside risks</li>
      </ul>
    </section>
  )
}