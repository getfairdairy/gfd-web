export default function Home() {
  return (
    <section className="w-full max-w-6xl mx-auto px-4 md:px-6 py-16 md:py-24">
      <span className="inline-flex items-center gap-2 text-sm rounded-full border px-3 py-1 bg-white/60 backdrop-blur-sm shadow-sm">EU Dairy data, unlocked</span>
      <h1 className="mt-4 text-4xl md:text-5xl font-extrabold leading-tight">Turn market noise into clear, tradable signals</h1>
      <p className="mt-4 text-lg text-gray-600 max-w-2xl">Real-time prices, trade blotter, and commentary for brokers, buyers and makers. Built by GFD.</p>
      <div className="mt-6 flex gap-3">
        <a className="px-4 py-2 rounded-xl border bg-white" href="/dashboard">Launch Web App</a>
        <a className="px-4 py-2 rounded-xl border" href="/advise">Book a demo</a>
      </div>
    </section>
  )
}