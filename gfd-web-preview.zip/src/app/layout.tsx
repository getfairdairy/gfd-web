import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'GFD Web',
  description: 'EU dairy market data: prices, trades, reports.'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <header className="sticky top-0 z-40 bg-white/70 backdrop-blur border-b">
          <div className="max-w-6xl mx-auto flex items-center justify-between px-4 md:px-6 py-3">
            <div className="font-semibold">GFD Web</div>
            <nav className="hidden md:flex items-center gap-6 text-sm">
              <a href="/" className="hover:underline">Home</a>
              <a href="/dashboard" className="hover:underline">Dashboard</a>
              <a href="/exchange" className="hover:underline">Exchange</a>
              <a href="/reports" className="hover:underline">Reports</a>
            </nav>
          </div>
        </header>
        <main>{children}</main>
        <footer className="border-t py-10">
          <div className="max-w-6xl mx-auto px-4 md:px-6 text-sm text-gray-600 flex items-center justify-between">
            <div>© {new Date().getFullYear()} Get Fair Dairy B.V.</div>
            <div className="opacity-70">MVP Preview</div>
          </div>
        </footer>
      </body>
    </html>
  )
}