import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

async function main() {
  await prisma.benchmark.createMany({ data: [
    { commodity: 'Butter (EU)', value: 6020, currency: '€' },
    { commodity: 'SMP (EU)', value: 2350, currency: '€' },
    { commodity: 'Gouda 48%', value: 3850, currency: '€' },
    { commodity: 'Whey Powder', value: 880, currency: '€' },
  ]})

  await prisma.trade.createMany({ data: [
    { commodity: 'Butter 82% CIF EU', side: 'SELL', qty: 50, price: 6000, incoterm: 'CIF', location: 'EU', date: new Date() },
    { commodity: 'Gouda 48% FOB NL', side: 'BUY', qty: 100, price: 3820, incoterm: 'FOB', location: 'NL', date: new Date() },
  ]})
}

main().then(() => prisma.$disconnect()).catch(async (e) => { console.error(e); await prisma.$disconnect(); process.exit(1) })